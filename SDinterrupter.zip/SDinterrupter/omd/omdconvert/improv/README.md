
* To download with git:  
   git clone http://github.com/craigsapp/improv.git
* To check for changes:  
   get status
* To store changes:  
   git commit -a
* To upload back to github:
   git push 

